#!/bin/bash
echo "Witaj w skrypcie nr 1"
